package com.example.rag.service;

import com.example.rag.dto.ChatResponse;
import com.example.rag.dto.SourceDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RagService {
    private static final Logger log = LoggerFactory.getLogger(RagService.class);
    private final ChatClient chatClient;
    private final VectorStore vectorStore;
    private final MessageChatMemoryAdvisor memoryAdvisor;
    private final int defaultTopK;
    private final double defaultThreshold;
    private final int memoryWindow;

    public RagService(ChatClient.Builder builder, VectorStore vectorStore, MessageChatMemoryAdvisor memoryAdvisor,
                      @Value("${rag.top-k:5}") int defaultTopK,
                      @Value("${rag.similarity-threshold:0.70}") double defaultThreshold,
                      @Value("${rag.memory-window:10}") int memoryWindow) {
        this.chatClient = builder.build();
        this.vectorStore = vectorStore;
        this.memoryAdvisor = memoryAdvisor;
        this.defaultTopK = defaultTopK;
        this.defaultThreshold = defaultThreshold;
        this.memoryWindow = memoryWindow;
    }

    public ChatResponse chat(String question, String conversationId, String filterExpression, Integer topK, Double threshold) {
        int k = topK == null ? defaultTopK : Math.max(1, Math.min(topK, 20));
        double score = threshold == null ? defaultThreshold : Math.max(0.0, Math.min(threshold, 1.0));
        SearchRequest.Builder request = SearchRequest.builder().query(question).topK(k).similarityThreshold(score);
        if (filterExpression != null && !filterExpression.isBlank()) request.filterExpression(filterExpression);
        List<Document> sources = vectorStore.similaritySearch(request.build());
        String context = sources.stream().map(d -> "[SOURCE documentId=" + d.getMetadata().get("documentId") + ", file=" + d.getMetadata().get("fileName") + ", chunk=" + d.getMetadata().get("chunkIndex") + "]\n" + d.getText()).reduce("", (a,b) -> a + "\n\n" + b);
        String system = "You are a document-grounded assistant. Answer using the supplied context. If the context does not contain the answer, say you do not have enough information. Do not invent facts.\n\nCONTEXT:\n" + context;
        log.info("RAG query conversationId={} topK={} threshold={} filterPresent={} sources={}", conversationId, k, score, filterExpression != null && !filterExpression.isBlank(), sources.size());
        String answer = chatClient.prompt().system(system).user(question)
                .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, conversationId).param(MessageChatMemoryAdvisor.CHAT_MEMORY_RETRIEVE_SIZE_KEY, memoryWindow))
                .call().content();
        List<SourceDto> sourceDtos = sources.stream().map(d -> new SourceDto(
                String.valueOf(d.getMetadata().get("documentId")), String.valueOf(d.getMetadata().get("fileName")),
                ((Number)d.getMetadata().getOrDefault("chunkIndex", 0)).intValue(), d.getScore())).toList();
        return new ChatResponse(answer, sourceDtos);
    }
}
