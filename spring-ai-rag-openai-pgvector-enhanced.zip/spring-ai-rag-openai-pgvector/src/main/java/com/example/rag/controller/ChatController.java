package com.example.rag.controller;

import com.example.rag.dto.ChatRequest;
import com.example.rag.dto.ChatResponse;
import com.example.rag.service.RagService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
@Tag(name = "Chat", description = "RAG question answering with conversation memory and citations")
public class ChatController {
    private final RagService ragService;
    public ChatController(RagService ragService) { this.ragService = ragService; }

    @PostMapping
    @Operation(summary = "Ask a question", description = "Retrieves relevant chunks, applies optional metadata filtering, uses chat memory, and returns source citations.")
    public ResponseEntity<ChatResponse> chat(@Valid @RequestBody ChatRequest request) {
        return ResponseEntity.ok(ragService.chat(request.question(), request.conversationId(), request.filterExpression(), request.topK(), request.similarityThreshold()));
    }
}
