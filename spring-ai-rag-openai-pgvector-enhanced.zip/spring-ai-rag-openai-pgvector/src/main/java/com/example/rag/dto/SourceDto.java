package com.example.rag.dto;

public record SourceDto(String documentId, String fileName, Integer chunkIndex, Double score) { }
