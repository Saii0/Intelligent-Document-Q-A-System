package com.example.rag.controller;

import com.example.rag.dto.UploadResponse;
import com.example.rag.service.DocumentIngestionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Size;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;

@RestController
@RequestMapping("/api/documents")
@Tag(name = "Documents", description = "Upload and index PDF documents")
public class DocumentController {
    private final DocumentIngestionService ingestionService;
    public DocumentController(DocumentIngestionService ingestionService) { this.ingestionService = ingestionService; }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Upload a PDF", description = "Uploads one PDF, chunks it, creates embeddings and stores chunks in PGVector.")
    public ResponseEntity<UploadResponse> upload(
            @Parameter(description = "PDF file") @RequestPart("file") @Size(max = 20_000_000) MultipartFile file,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String author) {
        var metadata = new java.util.HashMap<String, String>();
        if (category != null && !category.isBlank()) metadata.put("category", category);
        if (author != null && !author.isBlank()) metadata.put("author", author);
        return ResponseEntity.ok(ingestionService.ingest(file, metadata));
    }

    @PostMapping(value = "/upload-many", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Upload multiple PDFs")
    public ResponseEntity<java.util.List<UploadResponse>> uploadMany(@RequestPart("files") MultipartFile[] files) {
        if (files == null || files.length == 0) throw new IllegalArgumentException("At least one PDF is required");
        var result = new java.util.ArrayList<UploadResponse>();
        for (MultipartFile file : files) result.add(ingestionService.ingest(file, Collections.emptyMap()));
        return ResponseEntity.ok(result);
    }
}
