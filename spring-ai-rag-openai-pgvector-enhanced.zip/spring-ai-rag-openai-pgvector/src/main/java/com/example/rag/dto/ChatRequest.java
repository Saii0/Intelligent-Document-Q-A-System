package com.example.rag.dto;

import jakarta.validation.constraints.NotBlank;

public record ChatRequest(
        @NotBlank(message = "question is required") String question,
        @NotBlank(message = "conversationId is required") String conversationId,
        String filterExpression,
        Integer topK,
        Double similarityThreshold) { }
