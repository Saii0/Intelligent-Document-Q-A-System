package com.example.rag.dto;

public record UploadResponse(String documentId, String fileName, int chunksStored, String message) { }
