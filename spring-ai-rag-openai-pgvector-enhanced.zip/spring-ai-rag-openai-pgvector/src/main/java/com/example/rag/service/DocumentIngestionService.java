package com.example.rag.service;

import com.example.rag.dto.UploadResponse;
import com.example.rag.exception.DocumentIngestionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

@Service
public class DocumentIngestionService {
    private static final Logger log = LoggerFactory.getLogger(DocumentIngestionService.class);
    private final VectorStore vectorStore;
    private final Path uploadDir;
    private final int chunkSize;
    private final int minChunkSizeChars;
    private final int minChunkLengthToEmbed;
    private final int maxNumChunks;

    public DocumentIngestionService(VectorStore vectorStore,
                                    @Value("${rag.upload-dir:./data/uploads}") String uploadDir,
                                    @Value("${rag.chunk-size:800}") int chunkSize,
                                    @Value("${rag.min-chunk-size-chars:350}") int minChunkSizeChars,
                                    @Value("${rag.min-chunk-length-to-embed:5}") int minChunkLengthToEmbed,
                                    @Value("${rag.max-num-chunks:10000}") int maxNumChunks) {
        this.vectorStore = vectorStore;
        this.uploadDir = Path.of(uploadDir);
        this.chunkSize = chunkSize;
        this.minChunkSizeChars = minChunkSizeChars;
        this.minChunkLengthToEmbed = minChunkLengthToEmbed;
        this.maxNumChunks = maxNumChunks;
    }

    public UploadResponse ingest(MultipartFile file, Map<String, String> extraMetadata) {
        validate(file);
        String documentId = UUID.randomUUID().toString();
        String safeName = Optional.ofNullable(file.getOriginalFilename()).orElse("document.pdf").replaceAll("[^a-zA-Z0-9._-]", "_");
        Path target = uploadDir.resolve(documentId + "-" + safeName);
        try {
            Files.createDirectories(uploadDir);
            file.transferTo(target);
            TikaDocumentReader reader = new TikaDocumentReader(new FileSystemResource(target));
            List<Document> sourceDocs = reader.read();
            TokenTextSplitter splitter = TokenTextSplitter.builder()
                    .withChunkSize(chunkSize)
                    .withMinChunkSizeChars(minChunkSizeChars)
                    .withMinChunkLengthToEmbed(minChunkLengthToEmbed)
                    .withMaxNumChunks(maxNumChunks)
                    .withKeepSeparator(true)
                    .build();
            List<Document> chunks = splitter.split(sourceDocs);
            List<Document> enriched = new ArrayList<>(chunks.size());
            for (int i = 0; i < chunks.size(); i++) {
                Document d = chunks.get(i);
                Map<String, Object> metadata = new HashMap<>(d.getMetadata());
                metadata.put("documentId", documentId);
                metadata.put("fileName", safeName);
                metadata.put("chunkIndex", i);
                metadata.put("contentType", Optional.ofNullable(file.getContentType()).orElse("application/pdf"));
                extraMetadata.forEach(metadata::put);
                enriched.add(new Document(d.getId(), d.getText(), metadata));
            }
            vectorStore.add(enriched);
            log.info("Ingested file={} documentId={} sourceDocs={} chunks={} chunkSize={}", safeName, documentId, sourceDocs.size(), enriched.size(), chunkSize);
            return new UploadResponse(documentId, safeName, enriched.size(), "Document ingested successfully");
        } catch (Exception ex) {
            try { Files.deleteIfExists(target); } catch (IOException ignored) { }
            throw new DocumentIngestionException("Could not ingest " + safeName, ex);
        }
    }

    private void validate(MultipartFile file) {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("PDF file is required");
        String name = Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);
        if (!name.endsWith(".pdf") && !"application/pdf".equalsIgnoreCase(file.getContentType())) throw new IllegalArgumentException("Only PDF files are supported");
    }
}
