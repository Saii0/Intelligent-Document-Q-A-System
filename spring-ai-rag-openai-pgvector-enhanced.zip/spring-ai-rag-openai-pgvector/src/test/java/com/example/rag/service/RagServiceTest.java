package com.example.rag.service;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RagServiceTest {
    @Test void returnsSourcesFromVectorStore() {
        VectorStore store = mock(VectorStore.class);
        ChatClient.Builder builder = mock(ChatClient.Builder.class);
        MessageChatMemoryAdvisor advisor = mock(MessageChatMemoryAdvisor.class);
        ChatClient client = mock(ChatClient.class, RETURNS_DEEP_STUBS);
        when(builder.build()).thenReturn(client);
        Document source = new Document("chunk", java.util.Map.of("documentId", "doc-1", "fileName", "a.pdf", "chunkIndex", 2));
        when(store.similaritySearch(any())).thenReturn(List.of(source));
        when(client.prompt().system(anyString()).user(anyString()).advisors(any()).call().content()).thenReturn("answer");
        var service = new RagService(builder, store, advisor, 5, 0.7, 10);
        var response = service.chat("question", "conversation-1", null, null, null);
        assertEquals("answer", response.answer());
        assertEquals("doc-1", response.sources().get(0).documentId());
    }
}
