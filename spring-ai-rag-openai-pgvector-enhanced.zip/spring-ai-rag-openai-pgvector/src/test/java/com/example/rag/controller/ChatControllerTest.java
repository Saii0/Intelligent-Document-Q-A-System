package com.example.rag.controller;

import com.example.rag.dto.ChatResponse;
import com.example.rag.service.RagService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;
import java.util.List;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ChatController.class)
@Import(com.example.rag.exception.GlobalExceptionHandler.class)
class ChatControllerTest {
    @Autowired MockMvc mvc;
    @MockBean RagService ragService;

    @Test void validatesRequest() throws Exception {
        mvc.perform(post("/api/chat").contentType("application/json").content("{\"question\":\"\",\"conversationId\":\"x\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test void returnsChatResponse() throws Exception {
        when(ragService.chat(eq("hello"), eq("c1"), isNull(), isNull(), isNull())).thenReturn(new ChatResponse("world", List.of()));
        mvc.perform(post("/api/chat").contentType("application/json").content("{\"question\":\"hello\",\"conversationId\":\"c1\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.answer").value("world"));
    }
}
