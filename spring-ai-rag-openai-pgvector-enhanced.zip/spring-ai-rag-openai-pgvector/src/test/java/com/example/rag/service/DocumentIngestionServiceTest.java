package com.example.rag.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.mock.web.MockMultipartFile;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class DocumentIngestionServiceTest {
  @TempDir Path tempDir;
  @Test void rejectsNonPdf() {
    VectorStore store = mock(VectorStore.class);
    var service = new DocumentIngestionService(store, tempDir.toString(), 200, 50, 5, 100);
    var file = new MockMultipartFile("file", "x.txt", "text/plain", "hello".getBytes());
    assertThrows(IllegalArgumentException.class, () -> service.ingest(file, java.util.Map.of()));
    verifyNoInteractions(store);
  }
}
