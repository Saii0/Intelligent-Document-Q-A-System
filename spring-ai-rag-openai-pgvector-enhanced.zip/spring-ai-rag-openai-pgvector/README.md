# Spring AI RAG — OpenAI + PGVector

A resume-ready Retrieval-Augmented Generation (RAG) backend built with Spring Boot, Spring AI, OpenAI and PostgreSQL/PGVector.

## Features

1. PDF upload API
2. Multiple document ingestion
3. Metadata filtering (`category`, `author`, and arbitrary Spring AI filter expressions)
4. Conversation chat memory using `MessageChatMemoryAdvisor`
5. Source/citation information in every chat response
6. Centralized exception handling
7. Configurable token chunk size through `application.properties` / environment variables
8. Request/response REST DTOs with Bean Validation
9. Swagger/OpenAPI documentation
10. Docker Compose for PGVector and the application
11. Architecture and ingestion diagrams
12. Structured SLF4J logging
13. Unit and MVC integration tests

Spring AI's `VectorStore` supports similarity search with top-K, similarity threshold and metadata filter expressions. See the official documentation for PGVector metadata filtering.

## Architecture

```text
                         +----------------------+
                         |      REST Client     |
                         +----------+-----------+
                                    |
                    +---------------+---------------+
                    |                               |
             POST /documents/upload          POST /api/chat
                    |                               |
                    v                               v
          +-------------------+            +-------------------+
          | DocumentController|            |  ChatController   |
          +---------+---------+            +---------+---------+
                    |                                |
                    v                                v
          +-------------------+            +-------------------+
          | Ingestion Service |            |    RAG Service     |
          | Tika -> Splitter  |            | Retrieve -> Prompt |
          +---------+---------+            +----+----------+----+
                    |                           |          |
                    | embeddings               |          |
                    v                           v          v
          +-------------------+        +-----------+  +-----------+
          |     PGVector      |<-------| Embedding |  | ChatMemory|
          | PostgreSQL        |        |  OpenAI   |  | In-Memory  |
          +-------------------+        +-----------+  +-----------+
                                             |
                                             v
                                        +-----------+
                                        | OpenAI LLM|
                                        +-----------+
```

![RAG architecture](screenshots/rag_architecture.png)

## Requirements

- Java 21
- Maven 3.9+ (or IntelliJ/IDEA Maven support)
- Docker Desktop
- OpenAI API key

## Run locally from IntelliJ IDEA

### 1. Set API key

Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="your-key"
```

macOS/Linux:

```bash
export OPENAI_API_KEY="your-key"
```

### 2. Start PGVector

```bash
docker compose up -d pgvector
```

### 3. Open the project

Open the folder in IntelliJ IDEA and run `SpringAiRagApplication`.

### 4. Swagger

Open:

```text
http://localhost:8080/swagger-ui.html
```

OpenAPI JSON:

```text
http://localhost:8080/v3/api-docs
```

## Docker-only run

```bash
set OPENAI_API_KEY=your-key
# PowerShell: $env:OPENAI_API_KEY="your-key"
docker compose up --build
```

## API examples

### Upload one PDF

```bash
curl -X POST "http://localhost:8080/api/documents/upload?category=spring&author=spring-team" \
  -F "file=@spring-reference.pdf"
```

### Upload multiple PDFs

```bash
curl -X POST http://localhost:8080/api/documents/upload-many \
  -F "files=@manual.pdf" \
  -F "files=@policy.pdf"
```

### Ask a question

```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "question":"What is dependency injection?",
    "conversationId":"user-123",
    "topK":5,
    "similarityThreshold":0.70
  }'
```

### Metadata filtering

```json
{
  "question": "What is the deployment policy?",
  "conversationId": "user-123",
  "filterExpression": "category == 'policy'",
  "topK": 5,
  "similarityThreshold": 0.7
}
```

## Chunk configuration

Change these properties without changing Java code:

```properties
rag.chunk-size=800
rag.min-chunk-size-chars=350
rag.min-chunk-length-to-embed=5
rag.max-num-chunks=10000
```

For example:

```powershell
$env:RAG_CHUNK_SIZE="1200"
```

## Source/citation response

A successful chat response looks like:

```json
{
  "answer": "...",
  "sources": [
    {
      "documentId": "...",
      "fileName": "spring-reference.pdf",
      "chunkIndex": 12,
      "score": 0.84
    }
  ]
}
```

The application retrieves the source chunks itself so citations are returned independently of the LLM's generated text.

## Tests

Run:

```bash
./mvnw test
```

or on Windows:

```powershell
mvnw.cmd test
```

The included tests cover document validation/ingestion behavior and the chat HTTP layer with mocked RAG dependencies.

## Important production notes

- `InMemoryChatMemory` is intentionally simple for a demo/resume project. For production, replace it with JDBC/Redis/Cassandra-backed memory.
- Never commit `.env` or an OpenAI API key.
- Consider authentication/authorization and per-user document isolation before exposing this API publicly.
- Metadata filters should be validated/whitelisted if clients are untrusted.
